export class Element {
    constructor (id:any, name:string, price:number){
   this.id = id;
   this.product = name;
   this.price = price;
    }
    public id: number; 
    public product: string;
    public price: number;
   }
   