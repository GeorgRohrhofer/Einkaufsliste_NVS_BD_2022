import { Injectable } from '@angular/core';
import { Element } from './element';
@Injectable({ providedIn: 'root' })
export class DataService {
    constructor() { }
    TODOS: Element[] = [ { id: 0, product: 'Essen', price: 10 } ];
    newEntry: Element | undefined;
    getTodos() {
    return this.TODOS;
 }
 addTodo(product: string, price: number) {
    this.newEntry = {
    id: this.TODOS.length,
    product: product,
    price: price
    };
    this.TODOS.push(this.newEntry);
 } 
 deleteTodo(product: string ){
    this.TODOS.forEach( (item, index) => {
        if(item.product === product) this.TODOS.splice(index,1);
      });
 }
}
