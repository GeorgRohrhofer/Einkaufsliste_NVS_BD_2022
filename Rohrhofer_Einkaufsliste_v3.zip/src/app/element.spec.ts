import { Element } from './element';

describe('Element', () => {
  it('should create an instance', () => {
    expect(new Element()).toBeTruthy();
  });
});
